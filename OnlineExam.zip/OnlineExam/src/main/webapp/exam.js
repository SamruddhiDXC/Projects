
NoOfQuestions = 20;// Edit this value before adding questions 
Questions = Array(NoOfQuestions);
Answers = new Array(NoOfQuestions);
Choosed = false;
for (var i = 0 ; i < NoOfQuestions ; i++)
{
    Answers[i] = new Array(4);
}
CorrectAnswers = new Array(NoOfQuestions);

QuestionNo = 0;
Marks = 0;
OptionChoosed = 0;
Answer = 5;

function AnswerChoosed(Ans)
{
	Answer = Ans;
	Choosed = true;
}



function load()
{
	LoadQuestion();
}

function LoadQuestion()
{
	document.getElementById("Question").innerHTML = "(" + (QuestionNo + 1)+") : " + Questions[QuestionNo];
	document.getElementById("Option0").innerHTML = "(a) " + Answers[QuestionNo][0];
	document.getElementById("Option1").innerHTML = "(b) " + Answers[QuestionNo][1];
	document.getElementById("Option2").innerHTML = "(c) " + Answers[QuestionNo][2];
	document.getElementById("Option3").innerHTML = "(d) " + Answers[QuestionNo][3];		
	document.getElementById("Opt1").checked = false;	
	document.getElementById("Opt2").checked = false;	
	document.getElementById("Opt3").checked = false;	
	document.getElementById("Opt4").checked = false;
	Answer = 5;
}


function NextQuestion()
{      
	if(Answer == CorrectAnswers[QuestionNo])
	{
		Marks++;
	}
	if(Choosed)
	{
   	if(QuestionNo < NoOfQuestions - 1)
   	{	
   		QuestionNo++;
   		LoadQuestion();
   	}
   	else
   	{
   		alert("End of Examination \n"+"Marks Are : "+Marks+"");
   	}
   	Choosed = false;
	}
	else
	{
       alert("No option choosed yet.... ");
	}
}

Questions [0] =  "Which of the following option leads to the portability and security of Java?";
Answers[0][0] = "Bytecode is executed by JVM";
Answers[0][1] = "The applet makes the Java code secure and portable";
Answers[0][2] = "Use of exception handling";
Answers[0][3] = "Dynamic binding between objects";
CorrectAnswers[0] = 1;


Questions [1] = "Which of the following is not a Java features?"
Answers[1][0] = "Dynamic";
Answers[1][1] = "Architecture Neutral";
Answers[1][2] = "Use of pointers";
Answers[1][3] = "Object-oriented";
CorrectAnswers[1] = 3;

Questions [2] = "What is the return type of the hashCode() method in the Object class?";
Answers[2][0] = "Object";
Answers[2][1] = "int";
Answers[2][2] = "long";
Answers[2][3] = "void";
CorrectAnswers[2] = 2;

Questions [3] = "Which of the following is a valid long literal?";
Answers[3][0] = "ABH8097";
Answers[3][1] = "L990023";
Answers[3][2] = "904423";
Answers[3][3] = "0xnf029L";
CorrectAnswers[3] = 4;

Questions [4] = "What does the expression float a = 35 / 0 return?";
Answers[4][0] = "0";
Answers[4][1] = "Not a Number";
Answers[4][2] = "Infinity";
Answers[4][3] = "Run time exception";
CorrectAnswers[4] = 3;

Questions [5] = "Which of the following tool is used to generate API documentation in HTML format from doc comments in source code?"; 
Answers[5][0] = "javap tool";
Answers[5][1] = "javaw command";
Answers[5][2] = "Javadoc tool";
Answers[5][3] = "javah command";
CorrectAnswers[5] = 3;

Questions [6] = "Which method of the Class.class is used to determine the name of a class represented by the class object as a String?";
Answers[6][0] = "getClass()";
Answers[6][1] = "intern()";
Answers[6][2] = "getName()";
Answers[6][3] = "toString()";
CorrectAnswers[6] = 3;

Questions [7] = "In which process, a local variable has the same name as one of the instance variables?";
Answers[7][0] = "Serialization";
Answers[7][1] = "Variable Shadowing";
Answers[7][2] = "Abstraction";
Answers[7][3] = "Multi-threading";
CorrectAnswers[7] = 2;

Questions [8] = "Which of the following is true about the anonymous inner class?";
Answers[8][0] = "It has only methods";
Answers[8][1] = "Objects can't be created";
Answers[8][2] = "It has a fixed class name";
Answers[8][3] = "It has no class name";
CorrectAnswers[8] = 4;

Questions [9] = "Which package contains the Random class?";
Answers[9][0] = "java.util package";
Answers[9][1] = "java.lang package";
Answers[9][2] = "java.awt package";
Answers[9][3] = "java.io package";
CorrectAnswers[9] = 1;

Questions [10] = "An interface with no fields or methods is known as a ______.";
Answers[10][0] = "Runnable Interface";
Answers[10][1] = "Marker Interface";
Answers[10][2] = "Abstract Interface";
Answers[10][3] = "CharSequence Interface";
CorrectAnswers[10] = 2;

Questions [11] = "Which of the following is an immediate subclass of the Panel class?";
Answers[11][0] = "Applet class";
Answers[11][1] = "Window class";
Answers[11][2] = "Frame class";
Answers[11][3] = "Dialog class";
CorrectAnswers[11] = 1;

Questions [12] = "Which option is false about the final keyword?";
Answers[12][0] = "A final method cannot be overridden in its subclasses.";
Answers[12][1] = "A final class cannot be extended.";
Answers[12][2] = "A final class cannot extend other classes.";
Answers[12][3] = "A final method can be inherited.";
CorrectAnswers[12] = 3;

Questions [13] = "Which of these classes are the direct subclasses of the Throwable class?";
Answers[13][0] = "RuntimeException and Error class";
Answers[13][1] = "Exception and VirtualMachineError class";
Answers[13][2] = "Error and Exception class";
Answers[13][3] = "IOException and VirtualMachineError class";
CorrectAnswers[13] = 3;

Questions [14] = "What do you mean by chained exceptions in Java?";
Answers[14][0] = "Exceptions occurred by the VirtualMachineError";
Answers[14][1] = "An exception caused by other exceptions";
Answers[14][2] = "Exceptions occur in chains with discarding the debugging information";
Answers[14][3] = "None of the above";
CorrectAnswers[14] = 2;

Questions [15] = "Which of the following is a marker interface?";
Answers[15][0] = "Runnable interface";
Answers[15][1] = "Remote interface";
Answers[15][2] = "Readable interface";
Answers[15][3] = "Result interface";
CorrectAnswers[15] = 2;

Questions [16] = "Which of the following is a reserved keyword in Java?";
Answers[16][0] = "object";
Answers[16][1] = "strictfp";
Answers[16][2] = "main";
Answers[16][3] = "system";
CorrectAnswers[16] = 2;

Questions [17] = "In java, jar stands for_____.";
Answers[17][0] = "Java Archive Runner";
Answers[17][1] = "Java Application Resource";
Answers[17][2] = "Java Application Runner";
Answers[17][3] = "None of the above";
CorrectAnswers[17] = 4;

Questions [18] = "What is the use of \w in regex?";
Answers[18][0] = "Used for a whitespace character";
Answers[18][1] = "Used for a non-whitespace character";
Answers[18][2] = "Used for a word character";
Answers[18][3] = "Used for a non-word character";
CorrectAnswers[18] = 3;

Questions [19] = "Which of the following is a mutable class in java?";
Answers[19][0] = "java.lang.String";
Answers[19][1] = "java.lang.Byte";
Answers[19][2] = "java.lang.Short";
Answers[19][3] = "java.lang.StringBuilder";
CorrectAnswers[19] = 4;



