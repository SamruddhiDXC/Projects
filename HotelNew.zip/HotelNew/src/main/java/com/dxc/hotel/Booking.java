package com.dxc.hotel;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Booking")
public class Booking {
private String bookId;
private String roomId;
private String custName;
private String city;
private Date bookDate;
private Date chkDate;

@Id
@Column(name="bookId")
public String getBookId() {
	return bookId;
}
public void setBookId(String bookId) {
	this.bookId = bookId;
}

@Column(name="roomId")
public String getRoomId() {
	return roomId;
}
public void setRoomId(String roomId) {
	this.roomId = roomId;
}

@Column(name="custName")
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}

@Column(name="city")
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

@Column(name="bookDate")
public Date getBookDate() {
	return bookDate;
}
public void setBookDate(Date bookDate) {
	this.bookDate = bookDate;
}

@Column(name="chkDate")
public Date getChkDate() {
	return chkDate;
}
public void setChkDate(Date chkDate) {
	this.chkDate = chkDate;
}






}
