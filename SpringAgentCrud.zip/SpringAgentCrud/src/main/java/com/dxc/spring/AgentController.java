package com.dxc.spring;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@RequestMapping("/agent")
@Controller
public class AgentController {

	
	@Autowired
	AgentDAO dao;
	
	@RequestMapping("/saveAgent") 
	public String saveData(@ModelAttribute("agent") Agent agent, Model m) {
		dao.insert(agent);
		List<Agent> list=dao.getAgent();  
        m.addAttribute("list",list);
		return "show-agent";
	}
	
	
	@RequestMapping("/editsave")
	public String editData(@ModelAttribute("agent") Agent agent, Model m) {
		int res = dao.update(agent);
		List<Agent> list=dao.getAgent();  
        m.addAttribute("list",list);
		return "show-agent";
	}
	
	
	@RequestMapping("/agentForm")
	public String addAgent(Model m) {
		m.addAttribute("command", new Agent());
		return "add-agent";
	}
	
	
	@RequestMapping("/showagent")
	public String showAgent(Model m) {
		List<Agent> list=dao.getAgent();  
        m.addAttribute("list",list);
		return "show-agent";
	}
	
	
	@RequestMapping("/editagent/{agentid}")
	public String editAgent(@PathVariable int agentid, Model m) {
		Agent result = dao.searchByAgentId(agentid);
		m.addAttribute("command",result);
		return "edit-agent";
	}
	
	
	 @RequestMapping("/deleteagent/{agentid}")  
	    public String delete(@PathVariable int agentid, Model m){  
	        dao.delete(agentid);  
	     
	        List<Agent> list=dao.getAgent();  
	        m.addAttribute("list",list);
			return "show-agent";
	    }   
	 

}

