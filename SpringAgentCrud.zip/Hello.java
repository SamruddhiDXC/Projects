package com.dxc.java;

/**
 * Program Simple Hello World.
 * @author Prasanna Trainer.
 */
public class Hello {
	/**
	 * Main method for calling the business logic.
	 * @param args for passing arguments.
	 */
	public static void main(String[] args) {
		System.out.println("Welcome to Java Programming...");
	}
}
