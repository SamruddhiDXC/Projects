package com.dxc.rest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class WalletDAO {
	public Wallet[] showWallet() {

			Connection con=ConnectionHelper.getConnection();

			try {

			PreparedStatement pst=con.prepareStatement("select count(*) cnt from Wallet");

			ResultSet rs=pst.executeQuery();

			rs.next(); 

			int cnt=rs.getInt("cnt"); 

			Wallet[] arr=new Wallet[cnt]; 

			pst=con.prepareStatement("select * from Wallet"); 

			rs=pst.executeQuery();

			int i=0;

			Wallet e=null;

			while(rs.next()) {

				e=new Wallet();

				e.setWAL_AMOUNT(rs.getDouble("WAL_AMOUNT"));

				e.setWAL_SOURCE(rs.getString("WAL_SOURCE"));

				arr[i]=e;

				i++;

			}

			return arr;

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

			return null;

		}

	}

}
