package com.dxc.rest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VendorDAO {
	public int authenticate(String user, String password) throws SQLException {

		Connection con = ConnectionHelper.getConnection();

		String cmd = "select count(*) cnt from vendor where VEN_USERNAME=? AND VEN_PASSWORD=?";

		PreparedStatement  pst = con.prepareStatement(cmd);

		pst.setString(1, user);

		pst.setString(2, password);

		ResultSet rs = pst.executeQuery();

		rs.next();

		int cnt = rs.getInt("cnt");

		return cnt;

	}
	public Vendor searchVendor(int VenId) {

		Connection con=ConnectionHelper.getConnection();

		try {

			PreparedStatement pst=con.prepareStatement("select * from vendor where VEN_ID=?");

			pst.setInt(1, VenId);

			ResultSet rs=pst.executeQuery();

			Vendor e = null;

			if(rs.next()) {

				e=new Vendor();

				e.setVenId(rs.getInt("VEN_ID"));

				e.setVEN_NAME(rs.getString("VEN_NAME"));

				e.setVEN_PHN_NO(rs.getString("VEN_PHN_NO"));

				e.setVEN_USERNAME(rs.getString("VEN_USERNAME"));

				e.setVEN_PASSWORD(rs.getString("VEN_PASSWORD"));

				e.setVEN_EMAIL(rs.getString("VEN_EMAIL"));

				}

			return e;

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

			return null;

		}
	}
	public Vendor[] showVendor() {

		Connection con=ConnectionHelper.getConnection();

		try {

			PreparedStatement pst=con.prepareStatement("select count(*) cnt from vendor");

			ResultSet rs=pst.executeQuery();

			rs.next(); 

			int cnt=rs.getInt("cnt"); 

			Vendor[] arr=new Vendor[cnt]; 

			pst=con.prepareStatement("select * from vendor"); 

			rs=pst.executeQuery();

			int i=0;

			Vendor e=null;

			while(rs.next()) {

				e=new Vendor();

				e.setVenId(rs.getInt("VEN_ID"));

				e.setVEN_NAME(rs.getString("VEN_NAME"));

				e.setVEN_PHN_NO(rs.getString("VEN_PHN_NO"));

				e.setVEN_USERNAME(rs.getString("VEN_USERNAME"));

				e.setVEN_PASSWORD(rs.getString("VEN_PASSWORD"));

				e.setVEN_EMAIL(rs.getString("VEN_EMAIL"));


				arr[i]=e;

				i++;

			}

			return arr;

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

			return null;

		}

	}

}
