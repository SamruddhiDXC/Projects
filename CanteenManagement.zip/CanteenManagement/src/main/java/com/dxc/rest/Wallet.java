package com.dxc.rest;

public class Wallet {
	private int WAL_ID;
		@Override
	public String toString() {
		return "Wallet [WAL_ID=" + WAL_ID + ", WAL_AMOUNT=" + WAL_AMOUNT + ", WAL_SOURCE=" + WAL_SOURCE + "]";
	}


		private Double WAL_AMOUNT;
	private String WAL_SOURCE;
	
	public int getWAL_ID() {
		return WAL_ID;
	}
	public void setWAL_ID(int wAL_ID) {
		WAL_ID = wAL_ID;
	}
	public Double getWAL_AMOUNT() {
		return WAL_AMOUNT;
	}
	public void setWAL_AMOUNT(Double wAL_AMOUNT) {
		WAL_AMOUNT = wAL_AMOUNT;
	}
	public String getWAL_SOURCE() {
		return WAL_SOURCE;
	}
	public void setWAL_SOURCE(String wAL_SOURCE) {
		WAL_SOURCE = wAL_SOURCE;
	}
	
	
	public Wallet() {
	}

}
