package com.dxc.rest;

public enum OrderStatus {
	
		PENDING, ACCEPTED, REJECTED 


}
