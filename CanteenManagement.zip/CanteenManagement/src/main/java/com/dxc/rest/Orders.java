package com.dxc.rest;

import java.sql.Date;

public class Orders {

	

	private int venId;
	
	private int ORD_ID;

	private int ORD_QUANTITY;
	
	private String WAL_SOURCE;

	private Double ORD_BILLAMOUNT;

	private OrderStatus  orderstatus;

	private String OrderComments;
	
	private int CustomerId;
	
	private int menuId;
	
	private Date orderDate;

	
	public int getVenId() {
		return venId;
	}

	public void setVenId(int venId) {
		this.venId = venId;
	}

	public Orders(int oRD_ID) {
		super();
		ORD_ID = oRD_ID;
	}

	public int getORD_ID() {
		return ORD_ID;
	}

	public void setORD_ID(int oRD_ID) {
		ORD_ID = oRD_ID;
	}

	public int getORD_QUANTITY() {
		return ORD_QUANTITY;
	}

	public void setORD_QUANTITY(int oRD_QUANTITY) {
		ORD_QUANTITY = oRD_QUANTITY;
	}

	public String getWAL_SOURCE() {
		return WAL_SOURCE;
	}

	public void setWAL_SOURCE(String wAL_SOURCE) {
		WAL_SOURCE = wAL_SOURCE;
	}

	public Double getORD_BILLAMOUNT() {
		return ORD_BILLAMOUNT;
	}

	public void setORD_BILLAMOUNT(Double oRD_BILLAMOUNT) {
		ORD_BILLAMOUNT = oRD_BILLAMOUNT;
	}

	public OrderStatus getOrderstatus() {
		return orderstatus;
	}

	public void setOrderstatus(OrderStatus orderstatus) {
		this.orderstatus = orderstatus;
	}
	public String getOrderComments() {
		return OrderComments;
	}

	public void setOrderComments(String orderComments) {
		OrderComments = orderComments;
	}
	
	
	public int getCustomerId() {
		return CustomerId;
	}

	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}

	public int getMenuId() {
		return menuId;
	}

	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Orders(int venId, int oRD_ID, int oRD_QUANTITY, String wAL_SOURCE, Double oRD_BILLAMOUNT,
			OrderStatus orderstatus, String orderComments, int customerId, int menuId, Date orderDate) {
		super();
		this.venId = venId;
		ORD_ID = oRD_ID;
		ORD_QUANTITY = oRD_QUANTITY;
		WAL_SOURCE = wAL_SOURCE;
		ORD_BILLAMOUNT = oRD_BILLAMOUNT;
		this.orderstatus = orderstatus;
		OrderComments = orderComments;
		CustomerId = customerId;
		this.menuId = menuId;
		this.orderDate = orderDate;
	}

	@Override
	public String toString() {
		return "Orders [venId=" + venId + ", ORD_ID=" + ORD_ID + ", ORD_QUANTITY=" + ORD_QUANTITY + ", WAL_SOURCE="
				+ WAL_SOURCE + ", ORD_BILLAMOUNT=" + ORD_BILLAMOUNT + ", orderstatus=" + orderstatus
				+ ", OrderComments=" + OrderComments + ", CustomerId=" + CustomerId + ", menuId=" + menuId
				+ ", orderDate=" + orderDate + "]";
	}

	
	
	
		

}
