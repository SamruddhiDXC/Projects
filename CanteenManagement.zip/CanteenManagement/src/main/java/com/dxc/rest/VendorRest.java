package com.dxc.rest;

import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/vendor")
public class VendorRest {
		@GET
	
		@Path("/validate/{user}/{passcode}")
	
		@Produces(MediaType.APPLICATION_JSON)
	
		public int validate(@PathParam("user") String user, @PathParam("passcode") String passcode) throws SQLException {
	
		VendorDAO dao = new VendorDAO();
	
		return dao.authenticate(user, passcode);
		}
		
		@GET

		@Path("/searchVendor/{VEN_ID}")

		@Produces(MediaType.APPLICATION_JSON)

		public Vendor searchVendor(@PathParam("VEN_ID") int VEN_ID) {

		Vendor result = new VendorDAO().searchVendor(VEN_ID);

		return result;

		}
		@GET

		@Produces(MediaType.APPLICATION_JSON)

		public Vendor[] showVendor() {

		Vendor[] result = new VendorDAO().showVendor();

		return result;

		}

}
