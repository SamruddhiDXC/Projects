package com.dxc.rest;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public class OrderDAO  {
	public String placeorder (int CusID, int VenId, int MenuId, String WaletSource,Date Ord_Date,int OrdQty,String ORD_COMMENTS) throws SQLException {
	Connection conn = ConnectionHelper.getConnection();
	PreparedStatement pst=null;
	ResultSet rs=null;
	String result="";
	
	OrderStatus ostatus = OrderStatus.APPROVED;

	int ORD_ID = generateORD_ID();
	
		String cmd="select MEN_PRICE from menu where MEN_Id=?";
		pst = conn.prepareStatement(cmd);
					pst.setInt(1, MenuId);
						rs = pst.executeQuery();
						rs.next();
						int price = rs.getInt("MEN_PRICE");
					
			   int ORD_BILLAMOUNT = price * OrdQty;	
				
				
			String cmdAmt = "select WAL_AMOUNT from wallet where CUS_ID=?";
			pst = conn.prepareStatement(cmdAmt);
			pst.setInt(1,CusID );
			rs = pst.executeQuery();
			rs.next();
			
			int walAmt = rs.getInt("WAL_AMOUNT");
			
			if(ORD_BILLAMOUNT>walAmt) {
				return "Insufficient balance...";
			}else if(ORD_BILLAMOUNT<walAmt) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String oDate = sdf.format(Ord_Date);
					cmd="insert into Orders " + 
							"(CUS_ID,VEN_ID,WAL_SOURCE,MEN_ID,ORD_DATE,ORD_QUANTITY,ORD_BILLAMOUNT,ORD_STATUS,ORD_COMMENTS,ORD_ID) \r\n" + " values(?,?,?,?,?,?,?,?,?,?)";
					pst=conn.prepareStatement(cmd);
				    pst.setInt(1, CusID);
					pst.setInt(2, VenId);
					
					String wSource="DEBIT_CARD";
					
					pst.setString(3, wSource);
					pst.setInt(4, MenuId);
					pst.setString(5, oDate);
					pst.setInt(6, OrdQty);
					pst.setDouble(7, ORD_BILLAMOUNT);
					
					String ordStatus = "PENDING";
					pst.setString(8, ordStatus);
					pst.setString(9, ORD_COMMENTS);
					pst.setInt(10, ORD_ID);
					pst.executeUpdate();		
					
			}
				
			String cmd1="update wallet set WAL_AMOUNT=WAL_AMOUNT-? where CUS_ID=?";
			pst = conn.prepareStatement(cmd1);
			pst.setInt(1, ORD_BILLAMOUNT);	
			pst.setInt(2,CusID);
			pst.executeUpdate();	
			return "Order Placed Successfully...";
			
				
		}

	private int generateORD_ID() throws SQLException {
		Connection conn = ConnectionHelper.getConnection();
		int ORD_ID=0;
	PreparedStatement pst = null;
		pst=conn.prepareStatement("SELECT CASE WHEN MAX(ORD_ID) IS NULL THEN 1 " + 
				"   ELSE MAX(ORD_ID)+1 END ORD_ID FROM Orders");
		ResultSet rs = pst.executeQuery();
		rs.next();
		ORD_ID = rs.getInt("ORD_ID");
		return ORD_ID;
		
	} 
	
	
	public Orders searchOrders(int ORD_ID) {

		Connection con=ConnectionHelper.getConnection();

		try {

			PreparedStatement pst=con.prepareStatement("select * from Orders where ORD_ID=?");

			pst.setInt(1, ORD_ID);

			ResultSet rs=pst.executeQuery();

			Orders e = null;

			if(rs.next()) {

				e=new Orders();

				e.setORD_ID(rs.getInt("ORD_ID"));

				e.setORD_QUANTITY(rs.getInt("ORD_QUANTITY"));

				e.setWAL_SOURCE(rs.getString("WAL_SOURCE"));

				e.setORD_BILLAMOUNT(rs.getDouble("ORD_BILLAMOUNT"));

				e.setORD_STATUS(rs.getString("ORD_STATUS"));

				e.setORD_COMMENTS(rs.getString("ORD_COMMENTS"));

				


			}

			return e;

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

			return null;

		}
	}
	
	
	public String approveDeny(int ORD_ID, int VEN_ID,int cusId ,String status, String ordComment) throws SQLException {

		Orders order = searchOrders(ORD_ID);

		int ordid=order.getORD_ID();
		
		Customer customer = new CustomerDAO().searchCustomer(cusId);
		
		int customers = customer.getCusId();

		System.out.println(cusId);

		System.out.println(customers);

		OrderStatus os = OrderStatus.APPROVED;

		Connection con = ConnectionHelper.getConnection();

		if (cusId==customers) {

			if (status.toUpperCase().equals("YES")) {

				status="APPROVED".trim();

				String cmd = "Update orders SET ORD_COMMENTS=? and ORD_STATUS=? WHERE ORD_ID=?";

				PreparedStatement pst = con.prepareStatement(cmd);

				pst.setString(1, ordComment.toString());

				pst.setString(2, os.toString());

				pst.setInt(3, ORD_ID);

				pst.executeUpdate();

				return "Order Approved...";

			} else {

				status="DENIED";

				return "Order Rejected...";

			}

		} else {

			return "Unauthorized Customer...";

		}
	}	
		
		
		public Orders[] orderHistory(int ordid) throws SQLException {

			Connection con = ConnectionHelper.getConnection();

		String cmd = "SELECT count(*) cnt FROM orders WHERE ORD_ID=?";

	PreparedStatement pst = con.prepareStatement(cmd);

		pst.setInt(1, ordid);

			ResultSet rs = pst.executeQuery();

			rs.next();

			int cnt = rs.getInt("cnt");

			System.out.println(cnt);

			Orders[] orders = new Orders[cnt];

			cmd = "select * from Orders WHERE ORD_ID=?";

			pst = con.prepareStatement(cmd);

			pst.setInt(1, ordid);

			rs=pst.executeQuery();

			Orders order = null;

			int i=0;

			while (rs.next()) {

				order = new Orders();

				order.setCustomerId(rs.getInt("CUS_ID"));

				order.setVendorId(rs.getInt("VEN_ID"));

				order.setWAL_SOURCE(rs.getString("WAL_SOURCE"));

				order.setmenuId(rs.getInt("MEN_ID"));

				order.setorderDate(rs.getDate("ORD_DATE"));
				
				order.setorderString(rs.getString("ORD_STATUS"));

				order.setORD_QUANTITY(rs.getInt("ORD_QUANTITY"));

				order.setORD_BILLAMOUNT(rs.getDouble("ORD_BILLAMOUNT"));

				order.setORD_COMMENTS(rs.getString("ORD_COMMENTS"));

				order.setORD_ID(rs.getInt("ORD_ID"));
			
				orders [i]= order;

				i++;

			}

			return orders;

		}

	
	

}
order1:

curl -vvv -H "Accept:application/json" -X POST -H "Content-Type:application/json" "localhost:8080/CanteenManagement/webapi/order/place/3/3/7/PAYTM/2020-07-30/1/YES/done"
"
z
curl -vvv -H "Accept:application/json" -X POST -H "Content-Type:application/json" "http://localhost:8080/CanteenManagement/webapi/order/place/3/3/6/PAYTM/2020-07-30/1/YES/done"
curl -vvv -H "Accept:application/json" -X POST -H "Content-Type:application/json" "localhost:8080/CanteenManagement/webapi/order/place/3/3/6/PAYTM/2020-07-30/1/YES/done"



order deny:

