package com.dxc.rest;

public class Vendor {
	

	
	private int venId;

	private String VEN_NAME;

	private String VEN_PHN_NO;

	private String VEN_USERNAME;

	private String VEN_PASSWORD;

	private String VEN_EMAIL ;
	
	

	public int getVenId() {
		return venId;
	}

	public void setVenId(int venId) {
		this.venId = venId;
	}

	public String getVEN_NAME() {
		return VEN_NAME;
	}

	public void setVEN_NAME(String vEN_NAME) {
		VEN_NAME = vEN_NAME;
	}

	public String getVEN_PHN_NO() {
		return VEN_PHN_NO;
	}

	public void setVEN_PHN_NO(String vEN_PHN_NO) {
		VEN_PHN_NO = vEN_PHN_NO;
	}

	public String getVEN_USERNAME() {
		return VEN_USERNAME;
	}

	public void setVEN_USERNAME(String vEN_USERNAME) {
		VEN_USERNAME = vEN_USERNAME;
	}

	public String getVEN_PASSWORD() {
		return VEN_PASSWORD;
	}

	public void setVEN_PASSWORD(String vEN_PASSWORD) {
		VEN_PASSWORD = vEN_PASSWORD;
	}

	public String getVEN_EMAIL() {
		return VEN_EMAIL;
	}

	public void setVEN_EMAIL(String vEN_EMAIL) {
		VEN_EMAIL = vEN_EMAIL;
	}

	public Vendor() {
	
		
	}
	
	@Override
	public String toString() {
		return "Vendor [venId=" + venId + ", VEN_NAME=" + VEN_NAME + ", VEN_PHN_NO=" + VEN_PHN_NO + ", VEN_USERNAME="
				+ VEN_USERNAME + ", VEN_PASSWORD=" + VEN_PASSWORD + ", VEN_EMAIL=" + VEN_EMAIL + "]";
	}
	
	public Vendor(int venId, String vEN_NAME, String vEN_PHN_NO, String vEN_USERNAME, String vEN_PASSWORD,
			String vEN_EMAIL) {
		super();
		this.venId = venId;
		VEN_NAME = vEN_NAME;
		VEN_PHN_NO = vEN_PHN_NO;
		VEN_USERNAME = vEN_USERNAME;
		VEN_PASSWORD = vEN_PASSWORD;
		VEN_EMAIL = vEN_EMAIL;
	}

}
