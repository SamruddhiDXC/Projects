package com.dxc.rest;

import java.sql.Date;
import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("order")

public class OrderRest 
{
	@POST
	@Path("/place/{CusID}/{VenId}/{MenuId}/{WaletSource}/{Ord_Date}/{OrdQty}/{OrderStatus}/{OrderComments}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)

		public String place(@PathParam("CusID") int custId, @PathParam("VenId") int venId, @PathParam("MenuId") int menuId, 
		@PathParam("WaletSource") String WaletSource, @PathParam("Ord_Date") Date Ord_Date, @PathParam("OrdQty") int OrdQty,
		@PathParam("orderstatus") String OrderStatus,
		@PathParam("OrderComments") String OrderComments) throws SQLException
	{
		OrderDAO dao = new OrderDAO();
		return dao.placeorder(custId, venId, menuId, WaletSource, Ord_Date, OrderComments, OrdQty, OrderStatus); 
	}
	@POST
	@Path("/{ORD_ID}/{VenId}/{status}/{OrderComments}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)

		public String approveDeny(@PathParam("ORD_ID") int ORD_ID, @PathParam("VenId") int VenId,
		@PathParam("status") String status,@PathParam("OrderComments") String OrderComments) throws SQLException 
	{
		String result = new OrderDAO().approveDeny(ORD_ID, VenId,status,OrderComments );
		return result;
	} 
	@POST

	@Path("searchOrder/{ORD_ID}")

	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)

		public Orders searchOrder(@PathParam("ORD_ID") int ordId) throws SQLException 
	{
		Orders result = new OrderDAO().searchOrders(ordId);
		return result;
	}

}


