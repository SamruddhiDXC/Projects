package com.dxc.rest;

public enum WalletSource {
	PAYTM,DEBIT_CARD,CREDIT_CARD 
}
